package com.example.sistemacompra;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Declare os CheckBoxes
    private CheckBox checkboxArroz, checkboxLeite, checkboxCarne, checkboxFeijao, checkboxRefrigerante;
    private TextView textTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar os CheckBoxes e o TextView
        checkboxArroz = findViewById(R.id.checkboxArroz);
        checkboxLeite = findViewById(R.id.checkboxLeite);
        checkboxCarne = findViewById(R.id.checkboxCarne);
        checkboxFeijao = findViewById(R.id.checkboxFeijao);
        checkboxRefrigerante = findViewById(R.id.checkboxRefrigerante);
        textTotal = findViewById(R.id.textTotal);

        // Botão de cálculo do total
        Button buttonCalcular = findViewById(R.id.buttonCalcular);
        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularTotal();
            }
        });
    }

    // Método para calcular o total
    private void calcularTotal() {
        double total = 0.0;

        // Verifica se os CheckBoxes estão marcados e soma os valores dos produtos
        if (checkboxArroz.isChecked()) {
            total += 2.69;
        }
        if (checkboxLeite.isChecked()) {
            total += 2.70;
        }
        if (checkboxCarne.isChecked()) {
            total += 16.70;
        }
        if (checkboxFeijao.isChecked()) {
            total += 3.38;
        }
        if (checkboxRefrigerante.isChecked()) {
            total += 3.00;
        }

        // Exibe o total na tela com duas casas decimais
        textTotal.setText(String.format("Total: R$ %.2f", total));
    }
}
