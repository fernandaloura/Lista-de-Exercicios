package com.example.novosalario;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etSalario;
    private RadioGroup radioGroupAumento;
    private Button btnCalcular;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os componentes
        etSalario = findViewById(R.id.etSalario);
        radioGroupAumento = findViewById(R.id.radioGroupAumento);
        btnCalcular = findViewById(R.id.btnCalcular);
        tvResultado = findViewById(R.id.tvResultado);

        // Configurando o botão de calcular
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obter o salário digitado
                String salarioTexto = etSalario.getText().toString();

                if (salarioTexto.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, insira o salário", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioTexto);

                // Obter o ID do botão de rádio selecionado
                int selectedId = radioGroupAumento.getCheckedRadioButtonId();
                double aumentoPercentual = 0;

                // Verificando o percentual de aumento selecionado
                if (selectedId == R.id.radio40) {  // Aumento de 40%
                    aumentoPercentual = 0.40;
                } else if (selectedId == R.id.radio45) {  // Aumento de 45%
                    aumentoPercentual = 0.45;
                } else if (selectedId == R.id.radio50) {  // Aumento de 50%
                    aumentoPercentual = 0.50;
                } else {
                    Toast.makeText(MainActivity.this, "Por favor, selecione um percentual de aumento!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Calculando o novo salário com o aumento
                double salarioReajustado = salario + (salario * aumentoPercentual);

                // Exibindo o resultado
                tvResultado.setText("Novo Salário: R$ " + String.format("%.2f", salarioReajustado));
            }
        });
    }
}




