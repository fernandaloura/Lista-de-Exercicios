package com.example.pizzaria;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class activity_resumo_pedido extends AppCompatActivity {

    TextView txtResumoDetalhes, txtValorTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido);

        // Inicializando as views
        txtResumoDetalhes = findViewById(R.id.txtResumoDetalhes);
        txtValorTotal = findViewById(R.id.txtValorTotal);

        // Recebendo dados da Intent
        String tipoPizza = getIntent().getStringExtra("TIPO_PIZZA");
        String tamanhoPizza = getIntent().getStringExtra("TAMANHO_PIZZA");
        String metodoPagamento = getIntent().getStringExtra("METODO_PAGAMENTO");
        double valorTotal = getIntent().getDoubleExtra("VALOR_TOTAL", 0);

        // Verificando se algum dado essencial está faltando
        if (tipoPizza == null || tipoPizza.isEmpty()) {
            tipoPizza = "Não selecionada";
        }
        if (tamanhoPizza == null || tamanhoPizza.isEmpty()) {
            tamanhoPizza = "Não selecionado";
        }
        if (metodoPagamento == null || metodoPagamento.isEmpty()) {
            metodoPagamento = "Não selecionado";
        }

        // Formatando o valor total para exibição
        DecimalFormat format = new DecimalFormat("R$ #,##0.00");

        // Atualizando os TextViews com os dados
        txtResumoDetalhes.setText("Pizza: " + tipoPizza + "\nTamanho: " + tamanhoPizza + "\nPagamento: " + metodoPagamento);
        txtValorTotal.setText("Valor Total: " + format.format(valorTotal));
    }
}


