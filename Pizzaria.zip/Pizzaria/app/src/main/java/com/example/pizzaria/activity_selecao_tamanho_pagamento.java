package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

public class activity_selecao_tamanho_pagamento extends AppCompatActivity {

    RadioGroup radioGroupTamanho, radioGroupPagamento;
    Button btnConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_tamanho_pagamento);

        radioGroupTamanho = findViewById(R.id.radioGroupTamanho);
        radioGroupPagamento = findViewById(R.id.radioGroupPagamento);
        btnConfirmar = findViewById(R.id.btnConfirmarTamanhoPagamento);

        // Recebendo o tipo de pizza da activity anterior
        String tipoPizza = getIntent().getStringExtra("TIPO_PIZZA");

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int idTamanho = radioGroupTamanho.getCheckedRadioButtonId();
                int idPagamento = radioGroupPagamento.getCheckedRadioButtonId();

                if (idTamanho == -1 || idPagamento == -1) {
                    // Nenhuma opção selecionada
                    return;
                }

                RadioButton radioTamanho = findViewById(idTamanho);
                RadioButton radioPagamento = findViewById(idPagamento);

                String tamanhoPizza = radioTamanho.getText().toString();
                String metodoPagamento = radioPagamento.getText().toString();

                // Define valores com base no tamanho
                double valorTotal = 0;
                switch (tamanhoPizza) {
                    case "Pequena":
                        valorTotal = 25.0;
                        break;
                    case "Média":
                        valorTotal = 35.0;
                        break;
                    case "Grande":
                        valorTotal = 45.0;
                        break;
                }

                // Intent para tela de resumo
                Intent intent = new Intent(activity_selecao_tamanho_pagamento.this, activity_resumo_pedido.class);
                intent.putExtra("TIPO_PIZZA", tipoPizza);
                intent.putExtra("TAMANHO_PIZZA", tamanhoPizza);
                intent.putExtra("METODO_PAGAMENTO", metodoPagamento);
                intent.putExtra("VALOR_TOTAL", valorTotal);
                startActivity(intent);
            }
        });
    }
}
