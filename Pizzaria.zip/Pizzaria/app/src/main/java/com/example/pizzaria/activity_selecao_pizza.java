package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class activity_selecao_pizza extends AppCompatActivity {

    CheckBox checkboxCalabresa, checkboxMarguerita, checkboxPortuguesa;
    Button btnConfirmarPizza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_pizza);

        checkboxCalabresa = findViewById(R.id.checkboxCalabresa);
        checkboxMarguerita = findViewById(R.id.checkboxMarguerita);
        checkboxPortuguesa = findViewById(R.id.checkboxPortuguesa);
        btnConfirmarPizza = findViewById(R.id.btnConfirmarPizza);

        btnConfirmarPizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder pizzaSelecionada = new StringBuilder();

                if (checkboxCalabresa.isChecked()) {
                    pizzaSelecionada.append("Calabresa, ");
                }
                if (checkboxMarguerita.isChecked()) {
                    pizzaSelecionada.append("Marguerita, ");
                }
                if (checkboxPortuguesa.isChecked()) {
                    pizzaSelecionada.append("Portuguesa, ");
                }

                // Verifica se ao menos uma pizza foi selecionada
                if (pizzaSelecionada.length() == 0) {
                    Toast.makeText(activity_selecao_pizza.this, "Por favor, selecione ao menos uma pizza", Toast.LENGTH_SHORT).show();
                } else {
                    // Remove a última vírgula e espaço, se houver
                    pizzaSelecionada.setLength(pizzaSelecionada.length() - 2);

                    // Passa os dados para a próxima Activity
                    Intent intent = new Intent(activity_selecao_pizza.this, activity_selecao_tamanho_pagamento.class);
                    intent.putExtra("TIPO_PIZZA", pizzaSelecionada.toString());
                    startActivity(intent);
                }
            }
        });
    }
}
