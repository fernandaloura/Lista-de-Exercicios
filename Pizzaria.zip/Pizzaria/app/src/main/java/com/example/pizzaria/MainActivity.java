package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnIniciarPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Assumindo que você tem um layout chamado activity_main.xml

        // Inicializando o botão
        btnIniciarPedido = findViewById(R.id.btnIniciarPedido);

        // Definindo o evento de clique do botão
        btnIniciarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Quando o botão for clicado, inicia a próxima atividade (Seleção de Pizza)
                Intent intent = new Intent(MainActivity.this, activity_selecao_pizza.class);
                startActivity(intent);
            }
        });
    }
}
