package com.example.lanchefacil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

public class FormularioActivity extends AppCompatActivity {

    private Button btnConfirmOrder;
    private TextInputEditText edtNome;
    private RadioGroup grupoLanches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_pedido);

        edtNome = findViewById(R.id.edtNome);
        grupoLanches = findViewById(R.id.radioGroupLanches);
        btnConfirmOrder = findViewById(R.id.btnConfirmOrder);

        btnConfirmOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = edtNome.getText().toString();
                int idSelecionado = grupoLanches.getCheckedRadioButtonId();

                if (nome.isEmpty()) {
                    edtNome.setError("Por favor, insira seu nome.");
                    return;
                }

                if (idSelecionado == -1) {
                    // Nenhum lanche foi selecionado
                    return;
                }

                RadioButton radioSelecionado = findViewById(idSelecionado);
                String lanche = radioSelecionado.getText().toString();

                // Envia os dados para a próxima Activity
                Intent intent = new Intent(FormularioActivity.this, ResumoActivity.class);
                intent.putExtra("NOME", nome);
                intent.putExtra("LANCHE", lanche);
                startActivity(intent);
            }
        });
    }
}
