package com.example.lanchefacil;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResumoActivity extends AppCompatActivity {

    private TextView tvResumoPedido;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido);

        tvResumoPedido = findViewById(R.id.tvResumoPedido);
        btnVoltar = findViewById(R.id.btnVoltar);

        // Recupera os dados da Intent
        String nome = getIntent().getStringExtra("NOME");
        String lanche = getIntent().getStringExtra("LANCHE");

        // Exibe o resumo do pedido
        tvResumoPedido.setText("Pedido de " + nome + ":\n" + lanche);

        // Configura o botão para voltar à tela inicial
        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(ResumoActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}



